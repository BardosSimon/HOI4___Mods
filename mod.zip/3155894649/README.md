# modifier-icons-lotr
This is a fork on the original modifier icons. All credits go to man.(That is his steam name I kid you not)
Link to that mod: https://steamcommunity.com/sharedfiles/filedetails/?id=2668048070